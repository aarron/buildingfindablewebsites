<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

// Pull parameters off URL and return as an array 
function getParams($baseUrl){
	if (!strstr($_SERVER['REQUEST_URI'],$baseUrl)){
	    trigger_error('$baseUrl is invalid: '.$baseUrl ); // error, URL is not valid
	}

	// pull paramters off of URI, replacing with an empty string
	if ($baseUrl != '/'){
	    $fragment = str_replace($baseUrl,'',$_SERVER['REQUEST_URI']); 
	}else{
	    $fragment = $_SERVER['REQUEST_URI'];
	}
	
	$params = explode('/',$fragment); // convert "/" seperated params to an array
	return $params;
}
?>