<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

require_once('inc/getParams.php');
$parameters = getParams('/top-sellers/products/');

// uncomment to print parameter to the page for testing
// print_r($parameters); 

// Optionally transfer array values to variables
$color = $parameters[0];
$prodId = $parameters[1];

// Do some database query with retrieved parameters
?>