/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

function expandCollapseBoxes(){
    if(!document.getElementsByTagName){return;}
    
    var divs = document.getElementsByTagName("div");
    
	for (var i=0; i < divs.length; i++){
        if(divs[i].className == "expand"){
	    	divs[i].className ="collapse";
			
	        // Build close link
		    var closeLink = document.createElement("a");
		    closeLink.className = "close-box";
		    closeLink.href = "#";
			closeLink.innerHTML = "Expand";
		    divs[i].parentNode.insertBefore(closeLink,divs[i]);
			
		    // Create link behavior
		    closeLink.onclick = function(){
		        var displayBox = this.parentNode.getElementsByTagName("div")[0];
				if(this.innerHTML == "Expand"){
				    this.innerHTML = "Collapse";
				    displayBox.className ="expand";
				}else{
				    this.innerHTML = "Expand";
				    displayBox.className ="collapse";
				}
		    };
		}
	}
};
