/*///////////////////////////////////////////////////////////////////////
Part of the code for the book 
Building Findable Web Sites: web standards SEO and beyond
by Aarron Walter (aarron@aarronwalter.com)
http://www.buildingfindablesites.com
///////////////////////////////////////////////////////////////////////*/

window.onload = init;

function init(){
	if(!document.getElementsByTagName || !document.getElementById){return;}
	
	var nav = document.getElementById("catalog-nav");
	var navlinks = nav.getElementsByTagName("a");
	for (var i=0; i < navlinks.length; i++){
		navlinks[i].onclick = function() {
			urlarray = this.href.split("/");
			prodid = urlarray.length-1;
			loadProduct(urlarray[prodid]);
			return false;
		};
	};
};

// Ajax Content Loader /////////////////////////////////////////////
function loadProduct(prodId){
	var display = document.getElementById('product-display'); 		// ID of div for response display
	display.innerHTML = 'Loading ...';		// Show loading message
	var url = 'inc/getProduct.php'; 		// Path from index.html to server-side script
	var pars = 'prodid='+escape(prodId)+'&ajax=true'; 	// URL encoded address string
	
	var myAjax = new Ajax.Updater(display, url, {method:'get', parameters:pars});
}
