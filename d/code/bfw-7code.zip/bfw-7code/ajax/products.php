<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<title>Progressive Ajax</title>
		
		<link type="text/css" rel="stylesheet" href="css/default.css" />
	</head>
	<body>
		<div id="wrapper">
			<h1>Pottery Catalog</h1>
			<ul id="catalog-nav">
				<li><a href="products/1">Casserole Dish</a></li>
				<li><a href="products/2">Candy Dish</a></li>
				<li><a href="products/3">Soup Bowl</a></li>
				<li><a href="products/4">Salt and Pepper</a></li>
			</ul>
		
			<div id="product-display">
				<?php
				require_once('inc/getProduct.php');
				echo getProduct($_GET['prodid']);
				?>
			</div>
		</div>
	</body>
</html>