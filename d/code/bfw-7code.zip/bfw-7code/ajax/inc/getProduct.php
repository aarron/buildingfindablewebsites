<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

require_once("config.php");

function getProduct($prodid){
	if(!$prodid){ echo "Oops! We ran into some trouble getting info about this product."; exit; }
	
	// Connect to database
    $con = mysql_connect(DBHOST,DBUSER,DBPASS);
    mysql_select_db(DBNAME, $con);

	$productid = mysql_real_escape_string($prodid);

    $result = mysql_query("SELECT * FROM ajax_products WHERE id='$prodid'");
	 
	if(mysql_num_rows($result) == 0){ echo "Sorry, we couldn't find any information about this product."; }
	
	while ($row = mysql_fetch_array($result)) {
		$content = '
		<h3>'.$row['title'].'</h3>
		<p><img src="http://aarronwalter.com/book/7/i/'.$row['image'].'" alt="'.$row['title'].'" />'.$row['description'].'</p>
		<p><a href="/book/7/products/'.$row['id'].'/" title="Right click or control click to copy URL">Link to this page</a></p>';
	}

	return $content;
}

if($_GET['ajax']=='true'){ echo getProduct($_GET['prodid']); }
?>