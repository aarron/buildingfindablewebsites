<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

if(!$_GET['q']){
    // Error: No query supplied ?>
    <div class="errror">
        No results found because you forgot to enter search terms
    </div>
    <?  exit;
}

// Connect to MySQL database
$con = mysql_connect('hostname','dbusername','dbpassword');
mysql_select_db('dbname',$con);

$query = mysql_real_escape_string($_GET['q']);
$sql = "SELECT * FROM products WHERE title LIKE '%$query%' OR description LIKE '%$query%' ORDER BY datemodified DESC";
$result = mysql_query($sql,);

if(mysql_num_rows($result) > 0){
	// Display results
	while($row = mysql_fetch_array($result)){
		echo "<h3><a href=\"products/$row[id]\">$row[title]</a></h3>";
		echo "<p>$row[description]</p>";
	}
	
}else{
	// No results ?>
	<div class="message">
        Sorry, no results were found.
    </div>
	<?
}

// Log Search Query for Marketing Research
$sql = "INSERT INTO searches SET query='$query', date='".time()."', ip='$_SERVER[REMOTE_ADDR]'";
$result = mysql_query($sql,);
?>