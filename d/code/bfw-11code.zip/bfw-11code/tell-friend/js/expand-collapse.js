/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

function expandCollapseBoxes(){
    if(!document.getElementsByTagName){return;}
    
    var divs = document.getElementsByTagName("div");
    for (var i=0; i < divs.length; i++){
        if(divs[i].getAttribute("class") == "expand"){
	    divs[i].className ="collapse";
			
            // Build close link
	    var closeLink = document.createElement("a");
	    closeLink.className = "closed";
	    closeLink.href = "#";
	    var closeLabel = document.createTextNode("Tell a Friend");
	    closeLink.appendChild(closeLabel);
	    divs[i].parentNode.insertBefore(closeLink,divs[i]);
			
	    // Create link behavior
	    closeLink.onclick = function(){
	        var displayBox = this.parentNode.getElementsByTagName("div")[0];
			if(this.className == "closed"){
				this.className = "open";
		    	displayBox.className ="expand";
			}else{
		    	this.className = "closed";
		    	displayBox.className ="collapse";
			}
	    };
	}
    };
};
