<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

// NOTE: it's a good idea to add some spam prevention to this script
function tellFriend(){
	
		if(isset($_POST['submit'])){
			// Validation ///////////////////////////////////////////////
			$err = array(); // will store all errors found in form submission

			// Check sender info
			if( empty($_POST['senders-name']) ){ array_push($err,"Please include your name"); }
			
			if( empty($_POST['senders-email']) ){
				array_push($err,"Please include your email address");
			}elseif( !ereg("^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$", $_POST['senders-email']) ){
				array_push($err,"Your email address in invalid");
			}
			
			// Check friend's info
			if( empty($_POST['friends-name']) ){ array_push($err,"Please include your friend's name"); }
			
			if( empty($_POST['friends-email']) ){
				array_push($err,"Please include your friend's email address");
			}elseif( !ereg("^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$", $_POST['friends-email']) ){
				array_push($err,"Your friend's email address in invalid");
			}

			// Check for blank message
			if( empty($_POST['message']) ){ array_push($err,"No message provided"); }

			if(count($err) > 0){
				
				// Build and return error message
				for($i=0;$i<count($err);$i++){
					$message .= $err[$i] . '<br />';
				}
				return '<div class="error">'.$message.'</div>';
				exit;
				
			}

			// Send the email to friend
			if(mail($_POST['friends-email'],$_POST['senders-name']." Thinks You'll Dig This","
".$_POST['senders-name']." found something cool at MySite.com and thinks you should check it out.
You can view it at http://mysite.com/products/".$_POST['product-id']." 

".$_POST['senders-name']." had this to say ...
".$_POST['message']."

			","From:".$_POST['senders-email']."\r\nReply-to:".$_POST['senders-email'])){
					return "Tada! Your message has been sent!";
			}else{
				return "Doah! Something went awry with your message.";
			}
	
	}
}
?>