<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<title>Tell a Friend</title>
		<link type="text/css" rel="stylesheet" href="css/default.css" />
	</head>
	
	<body>
		<div id="product">
			<h2>Candy Dish</h2>
			<p id="description">
				<img src="i/candydish.jpg" alt="Candy Dish" />
				Proin at eros non eros adipiscing mollis. Donec semper turpis sed diam. 
				Sed consequat ligula nec tortor. Integer eget sem. Ut vitae enim eu est 
				vehicula gravida. Morbi ipsum ipsum, porta nec, tempor id, auctor vitae, purus. 
				Pellentesque neque. Nulla luctus erat vitae libero. Morbi ipsum ipsum, porta nec, tempor id, auctor vitae, purus. 
				Pellentesque neque. Nulla luctus erat vitae libero.			
			</p>
			<p id="price">$50</p>
		</div>
		
		<? require_once("inc/tell-friend.php"); ?>
		<div id="response"><?=tellFriend()?></div>
		<div class="display-box">
			<div class="expand">
				<form id="tellfriend" action="<?=$_SERVER['PHP_SELF']?>" method="post">
					<fieldset>
						<div class="notification">All fields required</div>
						<legend>Your Info</legend>
						<label for="senders-name">Your Name</label>
						<input type="text" name="senders-name" id="sender-name" value="<?=$_POST['senders-name']?>" />

						<label for="senders-email">Your Email</label>
						<input type="text" name="senders-email" id="sender-email" value="<?=$_POST['senders-email']?>" />
					</fieldset>

					<fieldset>
						<legend>Your Friend's Info</legend>
						<label for="friends-name">Friend's Name</label>
						<input type="text" name="friends-name" id="friends-name" value="<?=$_POST['friends-name']?>" />

						<label for="friends-email">Friend's Email</label>
						<input type="text" name="friends-email" id="friends-email" value="<?=$_POST['friends-email']?>" />
					</fieldset>

					<fieldset>
						<legend>Your Message</legend>
						<label for="message">Message</label>
						<textarea name="message" id="message" value="<?=$_POST['message']?>"></textarea>
					</fieldset>

					<input type="hidden" name="product-id" value="12" />

					<input type="submit" name="submit" value="Send" class="btn" />
				</form>
			</div> 
		</div>
		
		<script type="text/javascript" src="js/expand-collapse.js"></script>
		<script type="text/javascript" charset="utf-8">
			window.onload = expandCollapseBoxes;
		</script>
	</body>
</html>