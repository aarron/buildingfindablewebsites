<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

// Connect to database
require_once("config.php");
$con = mysql_connect(DBHOST,DBUSER,DBPASS);
mysql_select_db(DBNAME, $con);

function getReviews($productid){
	$sql = "SELECT * FROM reviews WHERE productid='$productid' 
			AND status='1' ORDER BY dateposted DESC";
	if(!$result = mysql_query($sql)){
		return '<span class="error">Duoh! There was a problem retrieving the reviews for this product.</span>';
	}elseif(mysql_num_rows($result) == 0){
		return 'No reviews are posted for this product';
	}else{
		while($row = mysql_fetch_array($result)){
			$reviews .= '
				<div class="review">'.stripslashes($row['review']).'
					<div class="review-meta">Posted by '.$row['reviewersname'].' on '.date("l F j, Y",$row['dateposted']).'</div>
				</div>';
		}
		return $reviews;
	}
}

function getReviewsOld($productid){
	$sql = "SELECT * FROM reviews WHERE productid='$productid' AND status='1' ORDER BY dateposted DESC";
	if($result = mysql_query($sql)){
		
		if(mysql_num_rows($result) > 0){
			$reviews = array();
			while($row = mysql_fetch_array($result)){
				$review = array('reviewersname'=>stripslashes($row['reviewersname']),'review'=>stripslashes($row['review']),'dateposted'=>$row['dateposted']);
				array_push($reviews,$review);
			}
			return $reviews;
		}else{
			return "No reviews are posted for this product";
		}
		
	}else{
		return "Duoh! There was a problem retrieving the reviews for this product.";
	}
}


function storeReview(){
	$adminemail = "you@example.com";
	$err = array();
	
	// Validation
	if(empty($_POST['reviewersname'])){ array_push($err,"Please include your name"); }
	if(empty($_POST['review'])){ array_push($err,"Don't forget to write a review!"); }
	if(count($err) > 0){
		
		// Build and return error message
		for($i=0;$i<count($err);$i++){
			$message .= $err[$i] . '<br />';
		}
		return '<div class="error">'.$message.'</div>';	
	}
	
	$reviewersname = mysql_real_escape_string(strip_tags($_POST['reviewersname']));
	$review = mysql_real_escape_string(strip_tags($_POST['review']));
	
	$sql = "INSERT INTO reviews SET productid='$productid', review='$review', reviewersname='$reviewersname', status='0', dateposted='".time()."'";
	if(!$result = mysql_query($sql)){
		return "Duoh! There was some trouble storing your review.";
	}else{
		
		// Grab reviewid for inclusion in email
		$reviewid = mysql_insert_id(); 
		
		// Send email to admin for review
		$message = "
		$reviewersname posted a new product review
		-------------------------------------------------------------
		$review
		-------------------------------------------------------------
		Confirm: http://example.com/vet-review.php?action=confirm&reviewid=$reviewid 
		Delete: http://example.com/vet-review.php?action=delete&reviewid=$reviewid		
		";
		
		if(mail($adminemail,"New product review to confirm",$message,"From:$adminemail\r\nReply-to:$adminemail")){
			return "Thanks for posting your review! It will be read by the site's head honcho before it will be added to the site.";
		}else{
			return "Duoh! There was some trouble letting the site's head honcho know about your review.";
		}
		
	}
	
}


function confirmReview($reviewid){
	if(!isset($reviewid)){ return "Sorry, we couldn't confirm the review because no review id was supplied"; }
	
	$reviewid = mysql_real_escape_string($reviewid);
	$sql = "UPDATE reviews SET status='1' WHERE reviewid='$reviewid'";
	if($result = mysql_query($sql)){
		return "The review has been posted!";
	}else{
		return "Duoh! There was some trouble when confirming the review.";
	}
}


function deleteReview($reviewid){
	if(!isset($reviewid)){ return "Sorry, we couldn't delete the review because no review id was supplied"; }
	
	$reviewid = mysql_real_escape_string($reviewid);
	$sql = "DELETE FROM reviews WHERE reviewid='$reviewid'";
	if($result = mysql_query($sql)){
		return "The review has been deleted!";
	}else{
		return "Duoh! There was some trouble when deleting the review.";
	}
}
?>