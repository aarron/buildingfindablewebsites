<?php
/*///////////////////////////////////////////////////////////////////////
Part of the code from the book 
Building Findable Websites: Web Standards, SEO, and Beyond
by Aarron Walter (aarron@buildingfindablewebsites.com)
http://buildingfindablewebsites.com

Distrbuted under Creative Commons license
http://creativecommons.org/licenses/by-sa/3.0/us/
///////////////////////////////////////////////////////////////////////*/

function tellFriend(){
	
	// Validation ///////////////////////////////////////////////
	$err = array(); // will store all errors found in form submission

	// Check sender info
	if( empty($_POST['senders-name']) ){ array_push($err,"Please include your name"); }
	
	if( empty($_POST['senders-email']) ){
		array_push($err,"Please include your email address");
	}elseif( !ereg("^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$", $_POST['senders-email']) ){
		array_push($err,"Your email address is invalid");
	}
	
	// Check friend's info
	if( empty($_POST['friends-name']) ){ array_push($err,"Please include your friend's name"); }
	
	if( empty($_POST['friends-email']) ){
		array_push($err,"Please include your friend's email address");
	}elseif( !ereg("^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$", $_POST['friends-email']) ){
		array_push($err,"Your friend's email address is invalid");
	}

	// Check for blank message
	if( empty($_POST['message']) ){ array_push($err,"No message provided"); }

	if(count($err) > 0){
		
		// Build and return error message
		for($i=0;$i<count($err);$i++){
			$message .= $err[$i] . '<br />';
		}
		return '<div class="error">'.$message.'</div>';
		
	}else{

		// Send the email to friend
		$message = $_POST['message']."\r\rCheck it out: http://example.com/products/".$_POST['product-id']."\r\r".$_POST['senders-name'];
		
		if(mail($_POST['friends-email'],"This is awesome!", $message,"From:".$_POST['senders-email']."\r\nReply-to:".$_POST['senders-email'])){
				return "Tada! Your message has been sent!";
		}else{
			return "Duoh! Something went awry with your message.";
		}
	}	
	
}
?>