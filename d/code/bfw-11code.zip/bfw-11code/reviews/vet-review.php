<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<title>Vet Product Review</title>
	<link rel="stylesheet" href="css/default.css" type="text/css" />
</head>
<body>
	<div id="vet-message">
	<?php
	require_once("inc/reviews.php");
	if(!isset($_GET['action']) or !isset($_GET['reviewid'])){
		echo "Sorry, this page can only be accessed by the site administrator";
	}else{
		
		switch($_GET['action']){
			case "confirm": echo confirmReview($_GET['reviewid']); break;
			case "delete": echo deleteReview($_GET['reviewid']); break;
			default: echo "Whoa, pardner! There's no way to vet this review if you don't indicate a valid action."; break;
		}
		
	}
	?>
	</div>
</body>
</html>
