<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<title>Product Catalog</title>
		<link type="text/css" rel="stylesheet" href="css/default.css" />
	</head>
	
	<body>
		<div id="product">
			<h2>Candy Dish</h2>
			<p id="description">
				<img src="i/candydish.jpg" alt="Candy Dish" />
				Proin at eros non eros adipiscing mollis. Donec semper turpis sed diam. 
				Sed consequat ligula nec tortor. Integer eget sem. Ut vitae enim eu est 
				vehicula gravida. Morbi ipsum ipsum, porta nec, tempor id, auctor vitae, purus. 
				Pellentesque neque. Nulla luctus erat vitae libero. Morbi ipsum ipsum, porta nec, tempor id, auctor vitae, purus. 
				Pellentesque neque. Nulla luctus erat vitae libero.			
			</p>
			<p id="price">$50</p>
			
			<ul id="social-networking">
				<li><a href="http://www.facebook.com/sharer.php?u=http://example.com/product.php&t=The Candy Dish" title="" class="icon digg">digg</a></li>
				<li><a href="" title="" class="icon facebook">facebook</a></li>
				<li><a href="" title="" class="icon delicious">delicious</a></li>
				<li><a href="" title="" class="icon reddit">reddit</a></li>
				<li><a href="" title="" class="icon stumbleupon">stumble upon</a></li>
			</ul>
			
			<!-- AddThis Bookmark Button BEGIN -->
			<script type="text/javascript">
			  addthis_url    = location.href;   
			  addthis_title  = document.title;  
			  addthis_pub    = 'aarron';     
			</script><script type="text/javascript" src="http://s7.addthis.com/js/addthis_widget.php?v=12" ></script>
			<!-- AddThis Bookmark Button END -->

		</div>
		
		<!-- Tell a Friend -->
		<? require_once("inc/tell-friend.php"); ?>
		<div class="response"><? if(isset($_POST['submit-friend'])){echo tellFriend();}?></div>
		<div class="display-box">
			<div class="expand">
				<form id="tellfriend" action="<?=$_SERVER['PHP_SELF']?>" method="post">
					<fieldset>
						<div class="notification">All fields required</div>
						<legend>Your Info</legend>
						<label for="senders-name">Your Name</label>
						<input type="text" name="senders-name" id="sender-name" value="<?=$_POST['senders-name']?>" />

						<label for="senders-email">Your Email</label>
						<input type="text" name="senders-email" id="sender-email" value="<?=$_POST['senders-email']?>" />
					</fieldset>

					<fieldset>
						<legend>Your Friend's Info</legend>
						<label for="friends-name">Friend's Name</label>
						<input type="text" name="friends-name" id="friends-name" value="<?=$_POST['friends-name']?>" />

						<label for="friends-email">Friend's Email</label>
						<input type="text" name="friends-email" id="friends-email" value="<?=$_POST['friends-email']?>" />
					</fieldset>

					<fieldset>
						<legend>Your Message</legend>
						<label for="message">Message</label>
						<textarea name="message" id="message">I love this thing! <?=$_POST['message']?></textarea>
					</fieldset>

					<input type="hidden" name="product-id" value="12" />
					<input type="submit" name="submit-friend" value="Send" class="btn" />
				</form>
			</div> 
		</div>
		
		<!-- Reviews -->
		<div id="reviews">
			<h4>Product Reviews</h4>
			<? require_once("inc/reviews.php"); ?>
			<div class="response"><? if(isset($_POST['submit-review'])){echo storeReview();}?></div>
			<div class="reviews"><?=getReviews(12)?></div>
		</div>

		<div id="post-review">
			<form id="review-form" action="<?=$_SERVER['PHP_SELF']?>" method="post">
				<fieldset>
					<div class="notification">All fields required</div>
					<legend>Review of This Product</legend>

					<label for="reviewersname">Your Name</label>
					<input type="text" name="reviewersname" id="reviewersname" value="<?=$_POST['reviewersname']?>" />

					<label for="review">Review</label>
					<textarea name="review" id="review"><?=$_POST['review']?></textarea>
				</fieldset>

				<input type="hidden" name="product-id" value="12" />
				<input type="submit" name="submit-review" value="Save" class="btn" />
			</form>
		</div>
		
		<script type="text/javascript" src="js/expand-collapse.js"></script>
		<script type="text/javascript" charset="utf-8">
			window.onload = expandCollapseBoxes;
		</script>
	</body>
</html>